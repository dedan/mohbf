"""This module is used to convert the original images in raw format
to more manageable TIFFs."""
# read images in raw format and transform to TIFF (16bit depth)
import numpy
import array
import Image
import os

# generate list of names:
# DIR+PFX+#DIGITS+SFX
# example: imc/imk00132.imc
DIR='/home/mohbf/images/raw/'
PFX='imk'
SFX='.imc'
DIGITS=5
# which images to load
IMAGES=range(1,3000)
names = [DIR+PFX+('%d'%i).zfill(DIGITS)+SFX for i in IMAGES]

def transform(x):
    x = x.astype('float64')
    # rescale to (0,1)
    x /= x.max()
    # now rescale it to span a dynamic range of 2 byte, i.e.
    # (0,2**16-1) [don't use the full range to avoid wrap-around]
    x *= 2**15-1
    # dtype means '<'=little-endian,'i'=integer,'2'=2-bytes    
    x = x.astype('<i2')
    return x
    
# load image
for name in names:
    print 'Reading', name
    if not os.path.exists(name):
        print 'Warning: %s does not exists!'%name
        continue
    raw = numpy.fromfile(name, dtype='>i2').reshape(1024,1536)
    # crop a 2x2 stripe as suggested in the original documentation
    raw = raw[2:1022,2:1534]
    raw = transform(raw)
    # transform to image
    img = Image.fromarray(raw)
    img.save(name[:-3]+'tiff', format='TIFF')
    # test that we get the same data after saving and loading
    #x = Image.open(name[:-3]+'tiff').tostring()
    #y = numpy.fromstring(x,dtype='<i2').reshape(1020,1532)
    #print abs(raw-y).max()
    
    
    
