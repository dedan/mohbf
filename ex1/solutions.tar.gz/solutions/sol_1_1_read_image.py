"""Read and show image from the database

Solution to 1.1
"""
import numpy
import sys
import os
import Image
import matplotlib
import pylab

# important to avoid spurious smoothening of images!
matplotlib.rcParams['image.interpolation'] = 'nearest'
DEFAULT_DIR = '/home/mohbf/images/'
DEFAULT_IMAGE = DEFAULT_DIR+'imk00001.tiff'

def read(name=None):
    # read the image as an argument to this script.
    # if no argument is given, use a default
    if name is None:
        if len(sys.argv) > 1:
            name = sys.argv[1]
        else:
            name = DEFAULT_IMAGE
    # check that name exists. if not use default
    if not os.path.exists(name):
        print 'Warning: "%s" ot found! Using: %s'%(name,DEFAULT_IMAGE)
        name = DEFAULT_IMAGE

    image = Image.open(name)
    Y, X = image.size
    image = numpy.fromstring(image.tostring(), dtype='<i2').reshape(X,Y)
    image = image.astype('float64')
    return image

def show(image, title=None, fig=True):
    if fig:
        pylab.figure()
    pylab.imshow(image)
    pylab.gray()
    if title is not None:
        pylab.title(title)
    pylab.colorbar()
    # save figure to a file
    pylab.savefig(get_filename())
    
def get_filename():
    counter = 0
    bname = sys.argv[0][:-3]
    ext = '.png' 
    while os.path.exists(bname+'_%d'%counter+ext):
        counter += 1
    return bname+'_%d'%counter+ext

if __name__ == '__main__':
    image = read()
    show(image)
    pylab.show()
