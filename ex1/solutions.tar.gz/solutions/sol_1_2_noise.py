"""Add noise to images

Solution to 1.2"""
import numpy
import pylab
from sol_1_1_read_image import read, show

def gaussian_filtered_naive(size, side, mean=0., std=1.):
    pixels = [(x,y) for x in range(size[0]) for y in range(size[1])]
    offset = side//2
    noise = numpy.random.normal(loc=mean, scale=std, size=size)
    fnoise = numpy.zeros(size)
    # loop through all pixels
    for (x,y) in pixels:
        # define the square
        x_max, x_min = min(x+offset,size[0]), max(x-offset,0)
        y_max, y_min = min(y+offset,size[1]), max(y-offset,0)
        # set the mean of the square as a value for this pixel 
        fnoise[x,y] = noise[x_min:x_max+1,y_min:y_max+1].mean()
    return fnoise

def gaussian_filtered(size, side, mean=0., std=1.):
    noise = numpy.random.normal(loc=mean, scale=std, size=size)
    filter_ = numpy.ones(side, 'd')/side
    temp = numpy.zeros(size)
    for i in range(size[0]):
        temp[i, :] = numpy.convolve(filter_, noise[i,:], 'same')
    for i in range(size[1]):
        noise[:, i] = numpy.convolve(filter_, temp[:,i], 'same')
    return noise    

if __name__ == '__main__':
    stddeviations = [100.,1000.,5000.,10000.,30000.]
    squares = [3, 5, 15, 29]

    image = read()

    # plot the original image
    show(image, title='Original Picture')
    # generate noise pictures to overlay
    # White Noise
    print 'White Noise'
    noisy = {}
    for std in stddeviations:
        print 'working on:', std
        noise = numpy.random.normal(loc=0.0, scale=std, size=image.shape)
        noisy[std] = image+noise
        show(noisy[std], title='Noisy (std=%f)'%std)

    # Filtered Gaussian Noise
    print 'Filtered Gaussian Noise'
    filtered = {}
    for side in squares:
        print 'working on', side
        fnoise = gaussian_filtered(image.shape, side, mean=0., std=10000.)
        filtered[side] = image+fnoise
        show(filtered[side], title='Filtered gaussian (side=%d)'%side)

    pylab.show()
