"""Get random patches from the image database

Solution to 1.3"""
from sol_1_1_read_image import read, show, DEFAULT_DIR
import numpy
import os
import sys

images = os.listdir(DEFAULT_DIR)
images.sort()

def normalize(x, axis=None):
    y = x.copy()
    y -= y.mean(axis=axis)
    y /= y.std(axis=axis)
    return y

def get_patch(image, size, origin, norm=False):
    """Return a patch of image.
    The patch has shape (size[0],size[1]) and its
    top-left egde is located at (origin[0],origin[1]).
    If using origin the patch would not fit into the image,
    origin is shifted to let the patch fit.

    Set norm=True to return a meanfree and unit variance patch."""
    X, Y = image.shape
    x0, y0 = origin
    x, y = size
    if x>X or y>Y:
        raise Exception('Patch too large: %s>%s)!'%(str(size),str(image.shape)))

    # Check that we fit in the boundary.
    # If not move the origin so that the patch still fits
    x_max, y_max = x0+x, y0+y
    if x_max > X:
        x0 -= x_max-X
        x_max = X
    if y_max > Y:
        y0 -= y_max-Y
        y_max = Y
    patch = image[x0:x_max,y0:y_max]
    if norm:
        patch = normalize(patch)        
    return patch
    
def get_random_patch(image, size, norm=False):
    """Return a random patch from image."""
    X, Y = image.shape
    x, y = size
    # get a random origin
    x0 = numpy.random.randint(X-x)
    y0 = numpy.random.randint(Y-y)
    return  get_patch(image, size, (x0,y0), norm=norm)

def get_random_patches(size, N, norm=False):
    """Return N random patches from the image collection.
    Patches are stacked into a 2-D numpy array, such that each
    row contains a patch.
    If norm=True normalize the set of patches.
    """
    patches = numpy.zeros((N, size[0]*size[1]))
    for i in range(N):
        # select a random image
        sys.stdout.write(30*'\b'+"Patch: %d/%d"%(i+1,N))
        sys.stdout.flush()
        flname = images[numpy.random.randint(len(images))]
        image = read(DEFAULT_DIR+flname)
        patches[i,:] = numpy.array(get_random_patch(image,
                                                    size, norm=norm)).ravel()
    sys.stdout.write('\n')
    sys.stdout.flush()
    if norm:
        return normalize(patches, axis=0)
    else:
        return patches

if __name__ == '__main__':
    import pylab
    image = read()
    show(image, title='Original Picture')
    patch = get_patch(image, (105,210), (300,400), norm=True)
    show(patch, title='Normed %dx%d patch centered at %s'%(105,210,(300,400)))
    rpatch = get_random_patch(image, (300,300))
    show(rpatch, title='Unnormed %dx%d random patch'%(300,300))
    N=4
    patches = get_random_patches((50,50), N)
    pylab.figure()
    pylab.suptitle('%d random patches (array representation)'%N)
    for i in range(1,N+1):
        pylab.subplot(2,2,i)
        patch = numpy.reshape(patches[i-1,:], (50,50))
        show(patch, fig=False)
    x = get_random_patches((10,10),200, norm=True)
    show(x, title='200 stacked (10,10) random patches (vector representation)')
    pylab.show()
