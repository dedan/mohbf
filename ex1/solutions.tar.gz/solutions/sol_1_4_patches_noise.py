"""Generate noise random patches.

Solution to 1.4"""
from sol_1_1_read_image import read, show
from sol_1_3_patches import get_random_patches, normalize
from sol_1_2_noise import gaussian_filtered
import numpy
import sys
import pylab


def get_white_patches(size, N, norm=False):
    """Return N white noise patches."""
    noise = numpy.random.normal(loc=0.0, scale=1, size=(N, size[0]*size[1]))
    if norm:
        return normalize(noise, axis=0)
    else:
        return noise

def get_filtered_patches(size, N, side=9, norm=False):
    """Return N filtered white noise patches.

    side - the side of the square for the averaging filter"""
    filtered = numpy.zeros((N, size[0]*size[1]))
    for i in range(N):
        sys.stdout.write(30*'\b'+"Patch: %d/%d"%(i+1,N))
        sys.stdout.flush()
        filtered[i, :] = gaussian_filtered(size, side, mean=0., std=1.).ravel()
    sys.stdout.write('\n')
    sys.stdout.flush()    
    if norm:
        return normalize(filtered, axis=0)
    else:
        return filtered

if __name__ == '__main__':
    image_patches = get_random_patches((16,16), 500, norm=True)
    white_patches = get_white_patches((16,16), 500, norm=True)
    filtered_patches = get_filtered_patches((16,16), 500, 9, norm=True)
    show(image_patches, title='Image Patches')
    show(white_patches, title='White Patches')
    show(filtered_patches, title='Filtered Patches')
    pylab.show()
