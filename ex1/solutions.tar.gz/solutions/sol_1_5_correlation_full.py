"""Calculate pairwise pixel correlations over pixel distance.

Calculate the correlation over all pixel pairs on a
single image and plot it as a function of the euclidean distance.

This could be probably done faster using 
scipy.signal.convolve2d(image,image,'same').

Solution to 1.5
"""
import numpy
from sol_1_1_read_image import read, show

# list of distances for which we want to calculate the correlations
# for example distances=[1,2,3] means we want to have the correlations
# of pixel with distances d <=1, 1<d<=2, 2<d<=3.
distances = [0,1,5,10,15,20]

# keep a cache of distances, so that we don't recalculate them if
# we already have them

DISTS = {}

def distance(x,y):
    """Return the Euclidean distance between pixel x and pixel y
    """
    if (x,y) in DISTS:
        return DISTS[(x,y)]
    elif (y,x) in DISTS:
        return DISTS[(y,x)]
    else:
        dist = numpy.sqrt((x[0]-y[0])**2+(x[1]-y[1])**2)
        DISTS[(x,y)] = dist
        return dist
    
def vicinity(p, dist_min, dist_max):
    """Given the coordinates of a pixel 'p', return a list of the
    coordinates of pixels which are located at a distance 'd' from 'p'
    such that: dist_min < d <= dist_max"""  
    # center
    x0, y0 = p
    # get the squares of side dist_max
    idist = int(dist_max)
    x_max, x_min = min(x0+idist,X), max(x0-idist,0)
    y_max, y_min = min(y0+idist,Y), max(y0-idist,0)
    scoords = [(row,col) for row in range(x_min,x_max)
               for col in range(y_min,y_max)]
    # for every point within the square, check that the euclidean
    # distance is smaller or equal than dist
    coords = []
    for pixel in scoords:
        d = distance(p,pixel)
        if (dist_min < d) and (d <= dist_max):
            coords.append(pixel)
    return coords

image = read()
Y, X = image.shape

dists = [(distances[i], distances[i+1]) for i in range(len(distances)-1)]
# given a dist_min and dist_max, go through all pixels in the image and
# collect the pixel pairs that are separated by a distance 'd' such that
# dist_min < d <= dist_max
PAIRS = {}
all_pixels = [(x,y) for x in range(X) for y in range(Y)]
for (dist_min, dist_max) in dists:
    print 'processing', (dist_min, dist_max)
    PAIRS[(dist_min, dist_max)] = []
    for pixel in all_pixels:
        neighbors = vicinity(pixel, dist_min, dist_max)
        pairs = [(pixel, p) for p in neighbors]
        # don't add duplicates
        for (p1, p2) in pairs:
            if (p2, p1) not in PAIRS[(dist_min, dist_max)]:
                PAIRS[(dist_min, dist_max)].append((p1, p2))

for dist in dists:
    print 'Dist:', dist
    print 'Pairs:', len(PAIRS[dist])

correlation = {}
for dist in dists:
    print 'processing', (dist_min, dist_max)
    # substitute every pixel with its intensity
    x = [(image[p1], image[p2]) for (p1, p2) in PAIRS[dist]]
    # make it an array now
    x = numpy.array(x)
    # remove the mean (columnwise)
    x -= x.mean(axis=0)
    # remove the standard deviations
    x /= x.std(axis=0, ddof=1)
    # calculate the correlation
    correlation[dist] = (x[:,0]*x[:,1]).sum()/(x.shape[0]-1)

print 'Correlations:', correlation

