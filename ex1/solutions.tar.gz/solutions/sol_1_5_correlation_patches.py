"""Calculate pairwise pixel correlations over pixel distance..

Extract random patches from random images and calculate the
correlations with respect to a reference pixel position. In this case
you can plot the correlation as a matrix, i.e. the correlation as a
function of the pixel position

Solution to 1.5
"""
import numpy
from sol_1_1_read_image import read, show, get_filename
from sol_1_3_patches import get_random_patches
from sol_1_4_patches_noise import get_white_patches, get_filtered_patches
import pylab

PATCH_SIZE = 41
NPATCHES = 5000

def get_correlation(patches):
    # select the reference pixel in the center of the patch
    p0 = patches.shape[1]//2

    # we now just need the row of the correlation matrix correspondent
    # to our pixel of interest.
    print "Calculate correlation matrix..."
    correlation = numpy.dot(patches.T, patches[:,p0])/NPATCHES

    # reshape the correlation array to be a matrix as large as the patches
    correlation.shape = (PATCH_SIZE, PATCH_SIZE)
    return correlation

def get_projection(correlation):
    # have a look at the average projection (average over north/south/east/west directions)
    orig = PATCH_SIZE//2
    projection = (correlation[orig::-1,orig] + correlation[orig:,orig] +
                  correlation[orig,orig::-1] + correlation[orig,orig:])/4
    return projection

def plot_all(correlation, projection, title):
    show(correlation, title=title+' Correlation')
    pylab.figure()
    pylab.subplot(311)
    pylab.plot(projection, "ro-")
    pylab.title(title+' Correlation Projection (linear scale)')

    # plot in log scale only until the correlation values are above zero
    # the rest is numerical noise
    # - find the index of the first negative number in projection
    neg_idx = (projection < 0).nonzero()[0][0]
    positive_projection = projection[:neg_idx]

    pylab.subplot(312)
    pylab.title(title+' Correlation Projection (log scale)')
    pylab.plot(numpy.log10(positive_projection), "go-")

    # fit a straight line to the positive projection, to show that
    # we are dealing with a power law. we remove the last
    # point in the positive projection because it's most probably only
    # noise
    x = numpy.arange(positive_projection.shape[0])[:-1]
    y = numpy.log10(positive_projection[:-1])

    xmean = x.mean()
    ymean = y.mean()
    # average sum of squares
    sx, sxy, syx, sy = numpy.cov(x, y, bias=1).ravel()
    # line values
    slope = sxy/sx
    intercept = ymean - slope*xmean
    # evaluate the line on the x axis
    line = intercept + slope*x

    pylab.subplot(313)
    pylab.title(title+' Correlation Projection (log scale) - linear fit')
    pylab.plot(numpy.log10(positive_projection[:-1]), "bo")
    pylab.plot(line, "m-")
    pylab.savefig(get_filename())


if __name__ == '__main__':
    DB = {'Natural Images': get_random_patches,
          'White Noise': get_white_patches,
          'Filtered White Noise': get_filtered_patches}

    for db, function in DB.items():
        print "Working on", db
        patches = function((PATCH_SIZE, PATCH_SIZE), NPATCHES, norm=True)
        
        correlation = get_correlation(patches)
        projection = get_projection(correlation)

        # store result
        DB[db] = (DB[db], correlation)
        
        plot_all(correlation, projection, db)

    pylab.show()
