"""Calculate and show the basis vectors of a Principal Component Analisys.

Solution to 1.6"""

import numpy
from sol_1_1_read_image import read, show, get_filename
from sol_1_3_patches import get_random_patches
from sol_1_4_patches_noise import get_white_patches, get_filtered_patches
import mdp
import pylab

PATCH_SIZE = 41
NPATCHES = 5000
PCA_COMPONENTS = 25

def visualize_basis(basis, title, loc_scale=False):
    pylab.figure()
    pylab.suptitle(title, fontsize=14)
    sqr = int(numpy.sqrt(basis.shape[1]))
    side = int(numpy.sqrt(basis.shape[0]))
    scale = max(abs(basis.min()), abs(basis.max()))
    for i in range(basis.shape[1]):
        pylab.subplot(sqr,sqr,i+1)
        if loc_scale:
            scale = max(abs(basis[:,i].min()), abs(basis[:,i].max()))
        pylab.imshow(numpy.reshape(basis[:,i], (side, side)),
                     vmin=-scale, vmax=+scale)
        pylab.gray()
        pylab.setp(pylab.gca(), 'xticklabels', [])
        pylab.setp(pylab.gca(), 'xticks', [])
        pylab.setp(pylab.gca(), 'yticklabels', [])
        pylab.setp(pylab.gca(), 'yticks', [])
    pylab.savefig(get_filename())

if __name__ == '__main__':
    DB = {'Natural Images': get_random_patches,
          'White Noise': get_white_patches,
          'Filtered White Noise': get_filtered_patches}
    for db, function in DB.items():
        print "Working on", db
        patches = function((PATCH_SIZE, PATCH_SIZE), NPATCHES, norm=True)
        
        pca = mdp.nodes.PCANode(output_dim=PCA_COMPONENTS)
        pca.train(patches)
        basis = pca.get_projmatrix()
        visualize_basis(basis, db+' - First %d PCA basis vectors'%PCA_COMPONENTS,
                        loc_scale=True)

    pylab.show()
