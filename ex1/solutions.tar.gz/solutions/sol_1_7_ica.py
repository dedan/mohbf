"""Calculate and show the basis vectors of an Independent Component Analisys.

Solution to 1.7"""

import numpy
from sol_1_1_read_image import read, show, get_filename
from sol_1_3_patches import get_random_patches
from sol_1_4_patches_noise import get_white_patches, get_filtered_patches
from sol_1_6_pca import visualize_basis
import mdp
import pylab

PATCH_SIZE = 32
NPATCHES = 5000
PCA_COMPONENTS = 256

if __name__ == '__main__':
     DB = {'Natural Images': get_random_patches}
     for db, function in DB.items():
         print "Working on", db
         patches = function((PATCH_SIZE, PATCH_SIZE), NPATCHES, norm=True)
         
         ica = mdp.nodes.FastICANode(approach='symm',
                                     g='tanh', fine_g='tanh',
                                     whitened=False, white_comp=PCA_COMPONENTS,
                                     max_it=10000, stabilization=True,
                                     limit=0.1, verbose=True)
         ica.train(patches)
         basis = ica.get_projmatrix()
         visualize_basis(basis, db+' - The %d ICA basis vectors'%PCA_COMPONENTS,
                         loc_scale=True)
         visualize_basis(basis, db+' - The %d ICA basis vectors'%PCA_COMPONENTS,
                         loc_scale=False)
         
     pylab.show()
